/*var firstName="Jhon";
console.log(firstName)
var lastName="Smith";
console.log(lastName)
var fullName=firstName+", "+lastName;
console.log(fullName)

var person = {
    firstName:"John",
    lastName:"Doe",
    age:50,
    eyeColor:"blue"
};
var txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var sln = txt.length;
console.log(sln)
;*/
/*Objects
function Person(first, last, age, eyecolor) {
    this.firstName = first;
    this.lastName = last;
    this.age = age;
    this.eyeColor = eyecolor;
}
var myFather = new Person("John", "Doe", 50, "blue");
var myMother = new Person("Sally", "Rally", 48, "green");
console.log(myFather.age);
*/
/*
var person = {
    firstName:"John",
    lastName: "Doe",
    fullName: function() {
        return this.firstName + " " + this.lastName;
    }
}
var myObject = {
    firstName:"Mary",
    lastName: "Doe",
}
person.fullName.apply(myObject);  // Will return "Mary Doe"
*/
/*for(i=0;i<5;i++){console.log(i)}*/
	
	/*JS DOM
var myElement=document.getElementsByClassName("intro");
document.getElementById("demo").innerHTML="El texto del parrafo es: " +myElement[0].innerHTML;

document.getElementById("p1").innerHTML="New Text";
*/
/*JS DOM CSS
document.getElementById("p1").style.color="blue";
document.getElementById("p1").style.fontFamily="Times roman";
document.getElementById("p1").style.fontSize="Larger";
*/
/*
var myCollection = document.getElementsByTagName("td");
document.getElementById("Result").innerHTML = myCollection.length;
*/
/*
var myNodelist = document.querySelectorAll("p");
var i;
for (i = 0; i < myNodelist.length; i++) {
    myNodelist[i].style.backgroundColor = "red";
}*/
